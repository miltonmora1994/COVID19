<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class encuesta extends Model
{
    protected $table = 'encuesta';
    protected $guarded = ['id'];
}
